#ifndef COMMON_INCLUDE
#define COMMON_INCLUDE

#include<iostream>
#include<iomanip>
#include<fstream>
#include<sstream>
#include<string>
#include<chrono>
#include<ctime>
#include<climits>
#include<cstddef>
#include<memory>
#include<filesystem>

#include<algorithm>
#include<array>
#include<list>
#include<vector>
#include<map>
#include<unordered_map>
#include<set>
#include<unordered_set>
#include<tuple>

#include"../lib/json/json.hpp"

#endif