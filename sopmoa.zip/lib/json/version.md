by **nlohmann** 
<br>link: *https://github.com/nlohmann/json*
<br>branch: *develop* 
<br>commit code: *8c391e04fe4195d8be862c97f38cfe10e2a3472e*
<br>date: 25/04/2024